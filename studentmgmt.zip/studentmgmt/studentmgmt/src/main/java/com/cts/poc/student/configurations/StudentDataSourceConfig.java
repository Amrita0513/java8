package com.cts.poc.student.configurations;


import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableJpaRepositories(
        basePackages = "com.cts.poc.student.repositories",
        entityManagerFactoryRef = "studentEntityManagerFactory",
        transactionManagerRef = "studentTransactionManager"
)
public class StudentDataSourceConfig {

    @Autowired
    Environment env;

    /**
     * Configures the datasource bean by reading from application.properties file using the prefix value
     * @return
     */
    @Bean(name = "studentDataSource")
    @ConfigurationProperties(prefix = "student.datasource")
    public DataSource studentDataSource() {
        DataSource dataSource = DataSourceBuilder.create().build();
        return dataSource;
    }

    /**
     * Configurs the entity manager factory builder bean
     * @return EntityManagerFactoryBuilder
     */
    @Bean(name = "studentEntityManagerFactoryBuilder")
    public EntityManagerFactoryBuilder articleEntityManagerFactoryBuilder() {
        return new EntityManagerFactoryBuilder(new HibernateJpaVendorAdapter(), new HashMap<>(), null);
    }

    /**
     * Configurs the entity manager factory bean. This is configured to create JPA EntityManagerFactory.
     * Additional JPA properties are provided to configure the used JPA provider
     * @param builder
     * @param dataSource
     * @return LocalContainerEntityManagerFactoryBean
     */
    @Bean(name = "studentEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean studentEntityManagerFactory(
            @Qualifier("studentEntityManagerFactoryBuilder") EntityManagerFactoryBuilder builder,
            @Qualifier("studentDataSource") DataSource dataSource) {
        Map<String, String> properties = new HashMap<>();
        properties.put("hibernate.hbm2ddl.auto", env.getProperty("spring.jpa.hibernate.ddl-auto"));
        properties.put("hibernate.show-sql", env.getProperty("spring.jpa.show-sql"));
        properties.put("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.dialect"));
        return builder.dataSource(dataSource)
                .packages("com.cts.poc.student.dto")
                .persistenceUnit("student_db")
                .properties(properties)
                .build();
    }

    /**
     * Configures the transaction manager bean to integrate the JPA provider with spring transaction management
     * @param entityManagerFactory
     * @return PlatformTransactionManager
     */
    @Bean(name = "studentTransactionManager")
    public PlatformTransactionManager studentTransactionManager(
            @Qualifier("studentEntityManagerFactory") EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }

    /**
     * Sets up the DataSource Initializer
     * @param dataSource
     * @return DataSourceInitializer
     */
    @Bean(name = "studentDataSourceInitializer")
    public DataSourceInitializer studentDataSourceInitializer(
            @Qualifier("studentDataSource") DataSource dataSource) {
        DataSourceInitializer dataSourceInitializer = new DataSourceInitializer();
        dataSourceInitializer.setDataSource(dataSource);
        ResourceDatabasePopulator databasePopulator = new ResourceDatabasePopulator();
        databasePopulator.addScript(new ClassPathResource("student-schema.sql"));
        databasePopulator.addScript(new ClassPathResource("student-data.sql"));
        
        dataSourceInitializer.setDatabasePopulator(databasePopulator);
        return dataSourceInitializer;
    }
}
