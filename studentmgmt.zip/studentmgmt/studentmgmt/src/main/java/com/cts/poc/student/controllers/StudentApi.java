package com.cts.poc.student.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cts.poc.student.dto.Student;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(description = "The get Student APIs", tags = { "Students" })
@RequestMapping("view/student")
public interface StudentApi {

	@ApiOperation(value = "GetStudentDetails", nickname = "get Students",

			response = Student.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Nice!", response = Student.class),
			@ApiResponse(code = 400, message = "Invalid ID supplied"),
			@ApiResponse(code = 404, message = "Request not found") })
	@GetMapping(produces = "application/json")
	public List<Student> getStudentDetails();

	@PostMapping
	public void addStudent(@RequestBody Student student);

}
