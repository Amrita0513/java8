package com.cts.poc.student.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.cts.poc.student.dto.Student;
import com.cts.poc.student.services.StudentService;

@RestController
public class StudentController implements StudentApi {

	

	@Autowired
	private StudentService studentService;

	@Override
	public List<Student> getStudentDetails() {

		List<Student> student = studentService.getStudent();

		return student;

	}

	@Override
	public void addStudent(Student student) {

		studentService.saveStudentDetails(student);

	}

}
