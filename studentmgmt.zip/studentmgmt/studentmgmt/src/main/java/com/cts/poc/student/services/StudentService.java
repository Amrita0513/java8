package com.cts.poc.student.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.poc.student.dto.Student;
import com.cts.poc.student.repositories.StudentRepository;

@Service
public class StudentService {

	@Autowired
	private StudentRepository studentRepository;

	public List<Student> getStudent() {
		List<Student> studentDetails;

		studentDetails = studentRepository.getStudent();
		return studentDetails;
	}

	public Student saveStudentDetails(Student student) {
	
		studentRepository.save(student);
		
		return student;
	}

}
