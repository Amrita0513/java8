insert into student
    values(1, 'Amrita','Bangalore');

insert into student
    values(2, 'Sonali','Pune');

insert into student
    values(3, 'Trisha','Pune');


