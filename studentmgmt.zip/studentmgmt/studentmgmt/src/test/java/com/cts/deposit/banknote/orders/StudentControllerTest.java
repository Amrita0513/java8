package com.cts.deposit.banknote.orders;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cts.poc.student.controllers.StudentController;
import com.cts.poc.student.dto.Student;
import com.cts.poc.student.services.StudentService;


@WebMvcTest(controllers = StudentController.class)
public class StudentControllerTest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	private StudentService studentService;

	@Test
	public void viewStudentDetails() throws Exception {

		List<Student> response = buildStudentResponse();
		Mockito.when(studentService.getStudent()).thenReturn(response);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/student/view/student")
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);

		MvcResult actualResponse = mvc.perform(requestBuilder).andReturn();

		String expectedOrderResponse = "{\"code\":\"BNM200\",\"description\":\"Success\",\"exceptionMessage\":null,\"messages\":null}";

		// JSONAssert.assertEquals(expectedOrderResponse,
		// actualOrderResponse.getResponse()
		// .getContentAsString(), false);

	}

	public List<Student> buildStudentResponse() {

		Student student = new Student();
		List<Student> studentList = new ArrayList<>();
		student.setStudentId(1L);
		student.setName("Amrita");
		student.setAddress("Pune");
		studentList.add(student);
		return studentList;

	}

}
